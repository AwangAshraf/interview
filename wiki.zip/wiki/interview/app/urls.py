from django.urls import path
from . import views


urlpatterns = [
    path('', views.home),
    
    path('buildings/', views.buildings),
    
    path('foods/', views.foods),
    
    path('games/', views.games),

    path('buildings2/', views.buildings2),

    path('buildings3/', views.buildings3),

    path('buildings4/', views.buildings4),

    path('buildings5/', views.buildings5),

    path('buildings6/', views.buildings6),

    path('buildings7/', views.buildings7),

    path('buildings8/', views.buildings8),

    path('buildings9/', views.buildings9),

    path('buildings10/', views.buildings10),

    path('foods2/', views.foods2),

    path('foods3/', views.foods3),

    path('foods4/', views.foods4),

    path('foods5/', views.foods5),

    path('foods6/', views.foods6),

    path('foods7/', views.foods7),

    path('foods8/', views.foods8),

    path('foods9/', views.foods9),

    path('foods10/', views.foods10),

    path('games2/', views.games2),

    path('games3/', views.games3),

    path('games4/', views.games4),

    path('games5/', views.games5),

    path('games6/', views.games6),

    path('games7/', views.games7),

    path('games8/', views.games8),

    path('games9/', views.games9),

    path('games10/', views.games10),









    


  
]
