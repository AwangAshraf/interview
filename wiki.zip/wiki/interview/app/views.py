from django.shortcuts import render, HttpResponse

from django.http import HttpResponse



# Create your views here.
def home(request):
	return render(request, 'app/home.html')

def buildings(request):
	return render(request, 'app/buildings.html')

def foods(request):
	return render(request, 'app/foods.html')

def games(request):
	return render(request, 'app/games.html')

def buildings2(request):
	return render(request, 'app/buildings2.html')

def buildings3(request):
	return render(request, 'app/buildings3.html')

def buildings4(request):
	return render(request, 'app/buildings4.html')

def buildings5(request):
	return render(request, 'app/buildings5.html')

def buildings6(request):
	return render(request, 'app/buildings6.html')

def buildings7(request):
	return render(request, 'app/buildings7.html')

def buildings8(request):
	return render(request, 'app/buildings8.html')

def buildings9(request):
	return render(request, 'app/buildings9.html')

def buildings10(request):
	return render(request, 'app/buildings10.html')

def foods2(request):
	return render(request, 'app/foods2.html')

def foods3(request):
	return render(request, 'app/foods3.html')

def foods4(request):
	return render(request, 'app/foods4.html')

def foods5(request):
	return render(request, 'app/foods5.html')

def foods6(request):
	return render(request, 'app/foods6.html')

def foods7(request):
	return render(request, 'app/foods7.html')

def foods8(request):
	return render(request, 'app/foods8.html')

def foods9(request):
	return render(request, 'app/foods9.html')

def foods10(request):
	return render(request, 'app/foods10.html')

def games2(request):
	return render(request, 'app/games2.html')

def games3(request):
	return render(request, 'app/games3.html')

def games4(request):
	return render(request, 'app/games4.html')

def games5(request):
	return render(request, 'app/games5.html')

def games6(request):
	return render(request, 'app/games6.html')

def games7(request):
	return render(request, 'app/games7.html')

def games8(request):
	return render(request, 'app/games8.html')

def games9(request):
	return render(request, 'app/games9.html')

def games10(request):
	return render(request, 'app/games10.html')






